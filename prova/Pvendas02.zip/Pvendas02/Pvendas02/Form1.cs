﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pvendas02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] vendasMes1 = new double[2, 4];
            double[,] vendasMes2 = new double[2, 4];
            double totalMes1 = 0;
            double totalMes2 = 0;
            

            for(int mes = 0; mes < 2; mes++)
            {
                for(int semana = 0; semana < 2; semana++)
                {
                    string vendasSeamana = Interaction.InputBox("Vendas na semana: ", "Digite o total de vendas na semana: ");

                    if (!double.TryParse(vendasSeamana, out vendasMes1[mes, semana]) || vendasMes1[mes, semana] < 0)
                    {
                        MessageBox.Show("Digite uma resposta válida!");
                        semana--;
                    }
                    else
                    {
                        totalMes1 = totalMes1 + vendasMes1[mes, semana];
                    }
                }
            }

            for (int mes = 0; mes < 2; mes++)
            {
                for (int semana = 0; semana < 2; semana++)
                {
                    string vendasSeamana = Interaction.InputBox("Vendas na semana:", "Digite o total de vendas na semana: ");

                    if (!double.TryParse(vendasSeamana, out vendasMes2[mes, semana]) || vendasMes2[mes, semana] < 0)
                    {
                        MessageBox.Show("Digite uma resposta válida!");
                        semana--;
                    }
                    else
                    {
                        totalMes2 = totalMes2 + vendasMes2[mes, semana];
                    }
                }
            }

            lstbxVendas.Items.Add("Total do mês: 1 Semana: Semana 1 " + vendasMes1[0, 0].ToString("f2"));
            lstbxVendas.Items.Add("Total do mês: 1 Semana: Semana 2 " + vendasMes1[0, 1].ToString("f2"));
            lstbxVendas.Items.Add("Total do mês: 1 Semana: Semana 3 " + vendasMes1[1, 0].ToString("f2"));
            lstbxVendas.Items.Add("Total do mês: 1 Semana: Semana 4 " + vendasMes1[1, 1].ToString("f2"));

            lstbxVendas.Items.Add(">> Total Mês: " + totalMes1.ToString("f2"));

            lstbxVendas.Items.Add("--------------------------------");

            lstbxVendas.Items.Add("Total do mês: 1 Semana: Semana 1 " + vendasMes2[0, 0].ToString("f2"));
            lstbxVendas.Items.Add("Total do mês: 1 Semana: Semana 2 " + vendasMes2[0, 1].ToString("f2"));
            lstbxVendas.Items.Add("Total do mês: 1 Semana: Semana 3 " + vendasMes2[1, 0].ToString("f2"));
            lstbxVendas.Items.Add("Total do mês: 1 Semana: Semana 4 " + vendasMes2[1, 1].ToString("f2"));

            lstbxVendas.Items.Add(">> Total Mês:   " + totalMes2.ToString("f2"));

            lstbxVendas.Items.Add("--------------------------------");

            lstbxVendas.Items.Add(">> Total Geral:   " + (totalMes1 + totalMes2).ToString("f2"));
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxVendas.Items.Clear();
        }
    }
}
