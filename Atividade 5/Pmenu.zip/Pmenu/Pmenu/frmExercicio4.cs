﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenu
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContarNumeros_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int tamanho = rchtxtFrase.Text.Length;
            int contaNumero = 0;

            while (contador < tamanho) 
            {
                if (char.IsNumber(rchtxtFrase.Text[contador])) 
                {
                    contaNumero++;
                }
                contador++;
            }
            MessageBox.Show("Existem " + contaNumero + " números na frase!");
        }

        private void btnContarLetras_Click(object sender, EventArgs e)
        {
            int contaLetras = 0;
            int contador = 0;
            int tamanho = rchtxtFrase.Text.Length;

            while (contador < tamanho)
            {
                if (char.IsLetter(rchtxtFrase.Text[contador])) 
                {
                    contaLetras++;
                }
                contador++;
            }
            MessageBox.Show("Existem " + contaLetras + " letras na frase!");
        }

        private void btnEspaco_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int tamanho = rchtxtFrase.Text.Length;

            while (contador < tamanho) 
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[contador])) 
                {
                    MessageBox.Show("O primeiro espaço em branco fica na posição: " + (contador + 1) + "!");
                    break;
                }
                contador++;
            }
        }
    }
}
