﻿namespace Pmenu
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnContarNumeros = new System.Windows.Forms.Button();
            this.btnEspaco = new System.Windows.Forms.Button();
            this.btnContarLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(504, 133);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(325, 96);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btnContarNumeros
            // 
            this.btnContarNumeros.BackColor = System.Drawing.SystemColors.Info;
            this.btnContarNumeros.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContarNumeros.Location = new System.Drawing.Point(405, 279);
            this.btnContarNumeros.Name = "btnContarNumeros";
            this.btnContarNumeros.Size = new System.Drawing.Size(166, 101);
            this.btnContarNumeros.TabIndex = 1;
            this.btnContarNumeros.Text = "Contar números";
            this.btnContarNumeros.UseVisualStyleBackColor = false;
            this.btnContarNumeros.Click += new System.EventHandler(this.btnContarNumeros_Click);
            // 
            // btnEspaco
            // 
            this.btnEspaco.BackColor = System.Drawing.SystemColors.Info;
            this.btnEspaco.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEspaco.Location = new System.Drawing.Point(588, 279);
            this.btnEspaco.Name = "btnEspaco";
            this.btnEspaco.Size = new System.Drawing.Size(166, 101);
            this.btnEspaco.TabIndex = 2;
            this.btnEspaco.Text = "Primeiro espaço em branco";
            this.btnEspaco.UseVisualStyleBackColor = false;
            this.btnEspaco.Click += new System.EventHandler(this.btnEspaco_Click);
            // 
            // btnContarLetras
            // 
            this.btnContarLetras.BackColor = System.Drawing.SystemColors.Info;
            this.btnContarLetras.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContarLetras.Location = new System.Drawing.Point(773, 279);
            this.btnContarLetras.Name = "btnContarLetras";
            this.btnContarLetras.Size = new System.Drawing.Size(166, 101);
            this.btnContarLetras.TabIndex = 3;
            this.btnContarLetras.Text = "Contar letras";
            this.btnContarLetras.UseVisualStyleBackColor = false;
            this.btnContarLetras.Click += new System.EventHandler(this.btnContarLetras_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1378, 637);
            this.Controls.Add(this.btnContarLetras);
            this.Controls.Add(this.btnEspaco);
            this.Controls.Add(this.btnContarNumeros);
            this.Controls.Add(this.rchtxtFrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnContarNumeros;
        private System.Windows.Forms.Button btnEspaco;
        private System.Windows.Forms.Button btnContarLetras;
    }
}