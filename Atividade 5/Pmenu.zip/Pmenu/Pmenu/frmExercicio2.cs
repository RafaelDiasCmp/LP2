﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenu
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnIguais_Click(object sender, EventArgs e)
        {
            if (String.Compare(txtPalavra1.Text, txtPalavra2.Text) == 0)
            {
                MessageBox.Show("Palavras iguais!");
            }
            else 
            {
                MessageBox.Show("Palavras diferentes!");
            }
        }

        private void btnInserir1_Click(object sender, EventArgs e)
        {
            int tamanhoMetade = txtPalavra2.Text.Length / 2;

            string primeiraMetade = txtPalavra2.Text.Substring(0, tamanhoMetade);
            string segundaMetade = txtPalavra2.Text.Substring(tamanhoMetade);

            string novoTexto = primeiraMetade + txtPalavra1.Text + segundaMetade;

            txtPalavra2.Text = novoTexto;

        }

        private void btnInserir2_Click(object sender, EventArgs e)
        {
            int tamanhoMetade = txtPalavra1.Text.Length / 2;

            string novoTexto = txtPalavra1.Text.Insert(tamanhoMetade, "**");

            txtPalavra2.Text = novoTexto;
        }
    }
}
