﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenu
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            
            int.TryParse(txtNumero1.Text, out int numero1);
            int.TryParse(txtNumero2.Text, out int numero2);

            if (numero1 >= numero2)
            {
                MessageBox.Show("Não é possível fazer o sorteio, número 1 deve ser menor que o número 2!");
            }
            else 
            {
                Random random = new Random();
                int numeroRandom = random.Next(numero1, numero2 + 1);

                txtNumero2.Text = numeroRandom.ToString();
            }
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNumero1.Text, out int numero1))
            {
                MessageBox.Show("Número inválido!");
                txtNumero1.Focus();
            }
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNumero2.Text, out int numero2)) 
            {
                MessageBox.Show("Número inválido!");
                txtNumero2.Focus();
            }
        }
    }
}
