﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasse
{
    internal class mensalista : empregado
    {
        public double SalarioMensal { get; set; }

        public override double SalarioBruto()
        {
            return SalarioMensal;
        }
        public mensalista()
        {
            System.Windows.Forms.MessageBox.Show("Aqui é o mensalista!");
        }
        public mensalista (int matx, string nome, DateTime datax, double salx)
        {
            this.NomeEmpregado = nome;
            this.Matricula = matx;
            this.DataEntradaEmpresa = datax;
            this.SalarioMensal = salx;
        }
    }
}
