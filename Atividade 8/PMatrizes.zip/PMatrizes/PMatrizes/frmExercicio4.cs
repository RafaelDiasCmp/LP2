﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExec_Click(object sender, EventArgs e)
        {   
            string[] nomes = new string[10];
            int[] caracter = new int[10];
            for (int i = 0; i < nomes.Length; i++)
            {
                nomes[i] = Interaction.InputBox("Nome das pessoas", "Digite o nome completo: ");
                caracter[i] = nomes[i].Replace(" ", "").Length; //mudar espaco em branco
            }
            for (int i = 0;i < nomes.Length;i++)
            {
                lstbxNomes.Items.Add("o nome: "+ nomes[i]+ " tem " + caracter[i]+ " caracteres");
            }
        }
    }
}
