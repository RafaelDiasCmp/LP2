﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string mensagem;
            char[,] respostasAlunos = new char[4, 10];
            char[] gabarito = new char[] { 'C', 'D', 'D', 'A', 'A', 'E', 'B', 'C', 'E', 'E' };
            char[] opcoesValidas = new char[] { 'A', 'B', 'C', 'D', 'E' };

            for (int aluno = 0; aluno < 8; aluno++)
            {
                for (int questao = 0; questao < 10; questao++)
                {
                    string entrada = Interaction.InputBox("Gabarito", "Digite suas respostas: ");

                    if (!char.TryParse(entrada, out respostasAlunos[aluno, questao]) || !opcoesValidas.Contains(respostasAlunos[aluno, questao]))
                    {
                        MessageBox.Show("Insira uma resposta válida");
                        questao--;
                    }
                    else
                    {
                        bool acertou = respostasAlunos[aluno, questao] == gabarito[questao];
                        mensagem = $"O aluno {aluno + 1} {(acertou ? "acertou" : "errou")} a questão {questao + 1}. Escolheu '{respostasAlunos[aluno, questao]}' e a resposta correta era '{gabarito[questao]}'.";

                        lstbxGabarito.Items.Add(mensagem);
                    }
                }
            }

        }
    }
}
