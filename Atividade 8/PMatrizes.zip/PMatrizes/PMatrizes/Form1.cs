﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] nums = new int[20];
            string scan = "";
            for (int i = 0; i < nums.Length; i++)
            {
                scan = Interaction.InputBox("Digite o número", "Entrada de Dados");

                if (!int.TryParse(scan, out nums[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
                
            }
            Array.Reverse(nums);
            scan = "";
            foreach (int x in nums)
            {
                scan += x + "\n";
            }
            MessageBox.Show(scan);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            string output;
            output = "";
            ArrayList list = new ArrayList() { "Ana", "André", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
            list.Remove("Otávio");
            foreach (string s in list)
            {
                output += s + "\n";
            }
            MessageBox.Show(output);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double totalNotas = 0.0;
            string resultado;
            double[,] notasAlunos = new double[20, 3];
            double[] mediasAlunos = new double[20];

            for (int iAluno = 0; iAluno < 20; iAluno++)
            {
                for (int iNota = 0; iNota < 3; iNota++)
                {
                    resultado = Interaction.InputBox("Digite a nota " + (iNota + 1), "Aluno " + (iAluno + 1));
                    if (!double.TryParse(resultado, out notasAlunos[iAluno, iNota]) || notasAlunos[iAluno, iNota] > 10 || notasAlunos[iAluno, iNota] < 0)
                    {
                        MessageBox.Show("Número inválido");
                        iNota--;
                    }
                    else
                    {
                        totalNotas += notasAlunos[iAluno, iNota];
                    }
                }

                mediasAlunos[iAluno] = totalNotas / 3;
                totalNotas = 0.0;
            }

            resultado = "";

            for (int i = 0; i < 20; i++)
                resultado += "Aluno " + (i + 1) + ": Média: " + mediasAlunos[i].ToString("N2") + "\n";

            MessageBox.Show(resultado);
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            frmExercicio4 objExercicio4 = new frmExercicio4();
            objExercicio4.Show();
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            frmExercicio5 objExercicio5 = new frmExercicio5();
            objExercicio5.Show();
        }
    }

}