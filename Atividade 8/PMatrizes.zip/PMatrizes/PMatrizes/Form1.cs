﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using Microsoft.VisualBasic; //tem q colocar isso aq e o system.collection
using System.Collections;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http.Headers;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digite o número", "Entrada de Dados");

                if (!int.TryParse(auxiliar, out vetor[i])) //se n conseguir converter
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
                // dava pra fazer um else com uma nova string tipo "saida", e nesse else fazer um saida = vetor [i] + saida (desse jeito ja imprime invertido)
            }
            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int x in vetor)
            {
                auxiliar += x + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            string saida;
            saida = "";
            ArrayList lista = new ArrayList() { "Ana", "André", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais"};
            lista.Remove("Otávio");
            foreach (string s in lista)
            {
                saida += s + "\n";
            }
            MessageBox.Show(saida);

        }

        private void btnEx3_Click(object sender, EventArgs e)
        { 
            double soma = 0.0;
            string resposta;
            Double[,] notas = new double[20, 3];
            Double [] media = new double [20];
            for (var aluno = 0; aluno < 20; aluno++)
            {
                for (var nota = 0; nota < 3; nota++)
                {
                    resposta = Interaction.InputBox("Digite a nota " + (nota+1) , "Aluno "+ (aluno+1));
                    if (!double.TryParse(resposta, out notas[aluno,nota]) || notas[aluno, nota] > 10 || notas[aluno,nota] < 0)
                    {
                        MessageBox.Show("número inválido");
                        nota--;
                    }
                    else
                    {   
                        soma += notas[aluno, nota];
                    }
                }

                media[aluno] = soma / 3;
                soma = 0.0;
            }
            resposta = "";
           
            for (int c= 0; c < 20; c++)
                resposta += "Aluno "+ (c+1) +": média: "+ media[c].ToString("N2") + "\n";
            
            MessageBox.Show(resposta);
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            frmExercicio4 objExercicio4 = new frmExercicio4();
            objExercicio4.Show();
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            frmExercicio5 objExercicio5 = new frmExercicio5();
            objExercicio5.Show();
        }
    }
}