﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        Double lado1, lado2, lado3;

        private void txtbxLado1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtbxLado1.Text, out lado1))
            {
                MessageBox.Show("Número inválido!");
                txtbxLado1.Focus();
            }
            else
            {
                if (lado1 <= 0)
                {
                    MessageBox.Show("Número Inválido!");
                    txtbxLado1.Focus();
                }
            }
        }

        private void txtbxLado2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtbxLado2.Text, out lado2))
            {
                MessageBox.Show("Número inválido!");
                txtbxLado2.Focus();
            }
            else
            {
                if (lado2 <= 0)
                {
                    MessageBox.Show("Número inválido!");
                    txtbxLado2.Focus();
                }
            }
        }

        private void txtbxLado3_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtbxLado3.Text, out lado3))
            {
                MessageBox.Show("Número inválido!");
                txtbxLado1.Focus();
            }
            else
            {
                if (lado3 <= 0)
                {
                    MessageBox.Show("Número inválido!");
                    txtbxLado3.Focus();
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtbxLado1.Text = "";
            txtbxLado2.Text = "";
            txtbxLado3.Text = "";
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if ((lado1 < lado2 + lado3) && (lado1 > Math.Abs(lado2 - lado3)) && 
                (lado2 < lado1 + lado3) && (lado2 > Math.Abs(lado2 - lado3)) && 
                (lado3 < lado1 + lado2) && (lado3 > Math.Abs(lado1 - lado2))) 
            {
                
                if (lado1 == lado2 && lado2 == lado3)
                {
                    MessageBox.Show("Triângulo Equilátero!");
                }
                else if (lado1 != lado2 && lado2 != lado3 && lado1 != lado3)
                {
                    MessageBox.Show("Triângulo Escaleno!");
                }
                else
                {
                    MessageBox.Show("Triângulo Isóceles!");
                }
            }
            else
            {
                MessageBox.Show("Não é triângulo!");
            }
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
