﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcontato0030482411003
{
    public partial class frmSobre : Form
    {
        public frmSobre()
        {
            InitializeComponent();
        }
    }
}
