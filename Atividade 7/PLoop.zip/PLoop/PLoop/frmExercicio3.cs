﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoop
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnPalindromo_Click(object sender, EventArgs e)
        {
            string frase;
            string fraseRecebida;
            char[] palindromo;
            string compare;

            fraseRecebida = txtPalindromo.Text;
            frase = txtPalindromo.Text.ToUpper().Replace(" ", "");
            palindromo = frase.ToCharArray();

            Array.Reverse(palindromo);
            compare = new string(palindromo);
            if (String.Compare(frase, compare, true) == 0)
            {
                MessageBox.Show(fraseRecebida + " É um Palíndromo!");
            }
            else
            {
                MessageBox.Show(fraseRecebida + " Não é um Palíndromo!");
            }

     
            

        }
    }
}
