﻿namespace PLoop
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPalindromo = new System.Windows.Forms.TextBox();
            this.btnPalindromo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtPalindromo
            // 
            this.txtPalindromo.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPalindromo.Location = new System.Drawing.Point(514, 133);
            this.txtPalindromo.MaxLength = 50;
            this.txtPalindromo.Name = "txtPalindromo";
            this.txtPalindromo.Size = new System.Drawing.Size(274, 45);
            this.txtPalindromo.TabIndex = 0;
            // 
            // btnPalindromo
            // 
            this.btnPalindromo.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.btnPalindromo.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPalindromo.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnPalindromo.Location = new System.Drawing.Point(514, 239);
            this.btnPalindromo.Name = "btnPalindromo";
            this.btnPalindromo.Size = new System.Drawing.Size(274, 109);
            this.btnPalindromo.TabIndex = 1;
            this.btnPalindromo.Text = "Verificar se é palíndromo";
            this.btnPalindromo.UseVisualStyleBackColor = false;
            this.btnPalindromo.Click += new System.EventHandler(this.btnPalindromo_Click);
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1439, 651);
            this.Controls.Add(this.btnPalindromo);
            this.Controls.Add(this.txtPalindromo);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtPalindromo;
        private System.Windows.Forms.Button btnPalindromo;
    }
}