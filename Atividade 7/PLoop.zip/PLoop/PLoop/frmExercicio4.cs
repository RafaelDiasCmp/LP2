﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoop
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnSalarioBruto_Click(object sender, EventArgs e)
        {
            double salBruto, sal, prod, gratif, B, C, D;
            double.TryParse(txtProducao.Text, out prod);
            double.TryParse(txtGratificacao.Text, out gratif);
            double.TryParse(txtSalario.Text, out sal);

            if (prod >= 100)
            {
                B = 1;
            }
            else
            {
                B = 0;
            }
            if (prod >= 120)
            {
                C = 1;
            }
            else
            {
                C = 0;
            }
            if (prod >= 150)
            {
                D = 1;
            }
            else
            {
                D = 0;
            }

            salBruto = sal + sal * (0.05 * B + 0.1 * C + 1 * D) + gratif;

            if (salBruto > 7000 && (prod < 150 || gratif == 0))
            {
                salBruto = 7000;
            }
            MessageBox.Show("O salário bruto é " + salBruto);
        }
    }
    }
