﻿namespace PLoop
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBranco = new System.Windows.Forms.Button();
            this.btnLetraR = new System.Windows.Forms.Button();
            this.btnPar = new System.Windows.Forms.Button();
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnBranco
            // 
            this.btnBranco.BackColor = System.Drawing.Color.DimGray;
            this.btnBranco.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBranco.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnBranco.Location = new System.Drawing.Point(231, 324);
            this.btnBranco.Name = "btnBranco";
            this.btnBranco.Size = new System.Drawing.Size(297, 159);
            this.btnBranco.TabIndex = 0;
            this.btnBranco.Text = "Número de espaços em branco";
            this.btnBranco.UseVisualStyleBackColor = false;
            this.btnBranco.Click += new System.EventHandler(this.btnBranco_Click);
            // 
            // btnLetraR
            // 
            this.btnLetraR.BackColor = System.Drawing.Color.DimGray;
            this.btnLetraR.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetraR.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnLetraR.Location = new System.Drawing.Point(574, 324);
            this.btnLetraR.Name = "btnLetraR";
            this.btnLetraR.Size = new System.Drawing.Size(297, 159);
            this.btnLetraR.TabIndex = 1;
            this.btnLetraR.Text = "Número de letras \"R\"";
            this.btnLetraR.UseVisualStyleBackColor = false;
            this.btnLetraR.Click += new System.EventHandler(this.btnLetraR_Click);
            // 
            // btnPar
            // 
            this.btnPar.BackColor = System.Drawing.Color.DimGray;
            this.btnPar.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPar.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnPar.Location = new System.Drawing.Point(929, 324);
            this.btnPar.Name = "btnPar";
            this.btnPar.Size = new System.Drawing.Size(297, 159);
            this.btnPar.TabIndex = 2;
            this.btnPar.Text = "Quantidade de pares de letras iguais na frase";
            this.btnPar.UseVisualStyleBackColor = false;
            this.btnPar.Click += new System.EventHandler(this.btnPar_Click);
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.rchtxtFrase.Location = new System.Drawing.Point(484, 101);
            this.rchtxtFrase.MaxLength = 100;
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(464, 188);
            this.rchtxtFrase.TabIndex = 3;
            this.rchtxtFrase.Text = "";
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1462, 650);
            this.Controls.Add(this.rchtxtFrase);
            this.Controls.Add(this.btnPar);
            this.Controls.Add(this.btnLetraR);
            this.Controls.Add(this.btnBranco);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnBranco;
        private System.Windows.Forms.Button btnLetraR;
        private System.Windows.Forms.Button btnPar;
        private System.Windows.Forms.RichTextBox rchtxtFrase;
    }
}