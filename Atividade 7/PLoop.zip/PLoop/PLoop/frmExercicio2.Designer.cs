﻿namespace PLoop
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNumeroH = new System.Windows.Forms.Button();
            this.txtNumeroN = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnNumeroH
            // 
            this.btnNumeroH.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.btnNumeroH.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumeroH.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnNumeroH.Location = new System.Drawing.Point(557, 288);
            this.btnNumeroH.Name = "btnNumeroH";
            this.btnNumeroH.Size = new System.Drawing.Size(318, 141);
            this.btnNumeroH.TabIndex = 0;
            this.btnNumeroH.Text = "Gerar número H";
            this.btnNumeroH.UseVisualStyleBackColor = false;
            this.btnNumeroH.Click += new System.EventHandler(this.btnNumeroH_Click);
            // 
            // txtNumeroN
            // 
            this.txtNumeroN.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumeroN.Location = new System.Drawing.Point(491, 189);
            this.txtNumeroN.Name = "txtNumeroN";
            this.txtNumeroN.Size = new System.Drawing.Size(452, 45);
            this.txtNumeroN.TabIndex = 2;
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1434, 646);
            this.Controls.Add(this.txtNumeroN);
            this.Controls.Add(this.btnNumeroH);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnNumeroH;
        private System.Windows.Forms.TextBox txtNumeroN;
    }
}