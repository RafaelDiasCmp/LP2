﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Lifetime;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoop
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int contaBranco = 0;

            for (int i = 0; i < rchtxtFrase.Text.Length; i++) 
            {
                if (rchtxtFrase.Text[i] == ' ') 
                {
                    contaBranco++;
                }
            }
            MessageBox.Show("O número de espaços em branco é: " + contaBranco);
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            int contaLetraR = 0, i = 0;

            while (i < rchtxtFrase.Text.Length) 
            {
                if (rchtxtFrase.Text[i] == 'r' || rchtxtFrase.Text[i] == 'R') 
                {
                    contaLetraR++;
                }
                i++;
            }
            
            MessageBox.Show("O número de letras R é: " + contaLetraR);
        }

        private void btnPar_Click(object sender, EventArgs e)
        {
            int letrasPares = 0, i = 0;

            do
            {
                if (rchtxtFrase.Text[i] == rchtxtFrase.Text[i + 1])
                {
                    letrasPares++;
                }
                i++;
            }
            while (i < rchtxtFrase.Text.Length - 1);
            
            MessageBox.Show("O número de letras iguais em pares é: " + letrasPares);
        }
    }
}
